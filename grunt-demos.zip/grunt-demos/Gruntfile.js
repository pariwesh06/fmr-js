module.exports = function(grunt){
	//import plugins. Similar to java imports
	grunt.loadNpmTasks('grunt-contrib-uglify');
	grunt.loadNpmTasks('grunt-contrib-concat');
	grunt.loadNpmTasks('grunt-contrib-watch');
	 grunt.initConfig({
	 	watch: {
		      files: ['src/*', 'js/*'],
		      tasks: ['concat',  'uglify']
		   },
        uglify: {
		 target1: {
		 files: {
		 "build/bundle.js": ["src/test.js", "src/b.js", "src/c.js"]
		 		}
		 	}
		 },
		 concat: {
		 target1: {
		 files: {
		 "build/abc.js": ["src/test.js", "src/b.js", "src/c.js"]
		 		}
		 	}
		 }
    });
	 grunt.registerTask('default', ['concat:target1','uglify']);
}