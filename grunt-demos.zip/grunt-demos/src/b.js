function bar(){
  var user = {
    fname:'ram'
  }
  console.log(user)
}