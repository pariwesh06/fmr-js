function foo(){
	console.log('test1');
}