// var field =document.getElementById('fname');// $('#fname');
var fields = $('#fname');
fields.on('keyup', changeColor );
console.log(fields[0]);
var button=$('button');
//document.getElementsByTagName('button')
button.click(function(){
  console.log('test');
  $.ajax('http://it-ebooks-api.info/v1/search/net',{
    success:function(response){
      console.log(response);
    }
  })
})

function changeColor() {//event handler
  console.log(event.target.value);
    event.target.style.backgroundColor =event.target.value==""? 'red':'green';
}