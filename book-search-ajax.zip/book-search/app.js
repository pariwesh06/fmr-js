var table = $('#books');
// var field =document.getElementById('fname');// $('#fname');
var fields = $('#fname');
fields.on('keyup', changeColor );
console.log(fields[0]);
var button=$('button');
//document.getElementsByTagName('button')
button.click(function(){
  console.log('test');
  $.ajax('http://it-ebooks-api.info/v1/search/net',{
    success:function(response){//200 -399
      // console.log(response.Books);
      response.Books.map(function(book, index){
        var row = $('<tr>');
        var titleCell = $('<td>');
        titleCell.text(book.Title);
        row.append(titleCell);
        //add image
        var imageCell = $('<img>');
        imageCell.attr('src', book.Image);
        // imageCell.attr('style', 'height:30px; width: 30px');
        row.append(imageCell);
        table.append(row);
      })
    },
    error:function(xhr, status, error){//400-599
      alert('search failed', status, error);
    }
  })
})

function changeColor() {//event handler
  console.log(event.target.value);
    event.target.style.backgroundColor =event.target.value==""? 'red':'green';
}