import React from 'react';
// import {  Text,  TouchableHighlight,  View,} from 'react-native';
import Enzyme,{ shallow } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
// import * as  configureMockStore  from 'redux-mock-store';
const configureMockStore = require('redux-mock-store'); 
import AddItem from '../AddItem';
import thunk from 'redux-thunk';
// import RepoItem, { styles } from '../RepoItem';
// import { repos } from '../../../config/jest/mockData';
Enzyme.configure({ adapter: new Adapter() });


it('test search',()=>{

const middlewares = [thunk] // add your middlewares like `redux-thunk`
// const mockStore = configureStore(middlewares);
console.log('result=',configureMockStore )
const initialState={
  query:'java'
}
const mockStore= configureMockStore(middlewares)
  const wrapper = shallow(
      <AddItem />,  { context: { store: mockStore(initialState) } }
    );
})
