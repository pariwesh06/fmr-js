import { combineReducers } from 'redux';

import repos from './repos';

export default rootReducer = combineReducers({
  repos
});