var table = $('#books');
 var allRows = $('#books > tr');
// var field =document.getElementById('fname');// $('#fname');
var fields = $('#fname');
fields.on('keyup', changeColor);
console.log(fields[0]);
var button = $('button');
//document.getElementsByTagName('button')

button.click(function () {
  allRows.remove();//clear previous result
  $.ajax('https://raw.githubusercontent.com/pariwesh06/fmr-js/master/response.json', {
    success: function (response) {//200 -399
      // console.log(response.Books);
      response = JSON.parse(response);
      response.Books.map(function (book, index) {
        var row = $('<tr>');
        table.append(row);
        var titleCell = $('<td>');
        titleCell.text(book.Title);
        row.append(titleCell);
        //add isbn
        var isbnCell = $('<td>');
        isbnCell.text(book.isbn);
        row.append(isbnCell);
        row.get()[0].isbn = book.isbn;//
        // row.attr('isbn', book.isbn);
        //add image
        var imageCell = $('<img>');
        imageCell.attr('src', book.Image);
        // imageCell.attr('style', 'height:30px; width: 30px');
        row.append(imageCell);
        row.click(showDetails);
        //add delete button
        var btn = $('<BUTTON>');
        btn.text('delete');
        btn.click(deleteRow);
        var btnCell = $('<td>');
        btnCell.append(btn);
        row.append(btnCell);
      })
    },
    error: function (xhr, status, error) {//400-599
      alert('search failed', status, error);
    }
  })
})
function showDetails(){
  console.log(this.isbn);
  allRows.attr('style', 'background-color:white');
  $(this).attr('style', 'background-color:grey');
  $.ajax('https://github.com/pariwesh06/fmr-js/blob/master/details.json',{
    success:function(response){
      
    }
  })
}

function deleteRow() {
  if (confirm("Are you sure ?"))
    $(this).parent().parent().remove()
}

function changeColor() {//event handler
  console.log(event.target.value);
  event.target.style.backgroundColor = event.target.value == "" ? 'red' : 'green';
}